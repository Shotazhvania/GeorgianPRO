<?php

	define('XPEEDSTUDIO_EMAIL', 'developer.xspeed2018@gmail.com');
	define('XPEEDSTUDIO_SUBJECT', 'New Contact Email');
	define('XPEEDSTUDIO_SUCCESS_MASSAGE', 'Successfully Sent Email');

?>